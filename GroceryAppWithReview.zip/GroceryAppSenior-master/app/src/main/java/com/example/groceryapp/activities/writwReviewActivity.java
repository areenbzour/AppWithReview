package com.example.groceryapp.activities;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.groceryapp.R;
import com.example.groceryapp.adapters.AdapterSupermarket;
import com.example.groceryapp.models.ModelSupermarket;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class writwReviewActivity extends AppCompatActivity {
    private String ShopName, shopId;

    private ImageButton backBtn;
    private ImageView profileIv;
    private RatingBar ratingBar;
    private EditText reviewEt;
    private FloatingActionButton submitButn;
    private TextView shopNameTv;
    private TextView shopIdTv;
    private FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_writw_review);

        ModelSupermarket sm = (ModelSupermarket) getIntent().getSerializableExtra("supermarket");
        shopId = sm.getSupermarketId();

        backBtn = findViewById(R.id.backBtn);
        profileIv = findViewById(R.id.profileIv);
        shopNameTv = findViewById(R.id.shopNameTv);
        shopIdTv = findViewById(R.id.shopIdTv);
        ratingBar = findViewById(R.id.ratingBar);
        submitButn = findViewById(R.id.submitButn);
        reviewEt = findViewById(R.id.reviewEt);

        shopNameTv.setText(sm.getSupermarketName());
        shopIdTv.setText(sm.getSupermarketId());
        Picasso.get().load(sm.getSupermarketImage()).into(profileIv);


        firebaseAuth = FirebaseAuth.getInstance();
        //LoadShopInfo();
        //LoadReview();

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        submitButn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputData(view);
            }
        });
    }

    private void LoadReview() {
        FirebaseDatabase.getInstance().getReference("Supermarkets").child(shopId).child("Ratings").child(firebaseAuth.getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            String uid = "" + dataSnapshot.child(firebaseAuth.getUid()).getValue();
                            String ratings = "" + dataSnapshot.child("ratings").getValue();
                            String review = "" + dataSnapshot.child("review").getValue();
                            String timestamp = "" + dataSnapshot.child("timestamp").getValue();
                            Float myRating = Float.parseFloat(ratings);
                            ratingBar.setRating(myRating);
                            reviewEt.setText(review);

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    /* private void LoadShopInfo()
     {
          FirebaseDatabase.getInstance().getReference("Supermarkets").child(shopId)
                 .addValueEventListener(new ValueEventListener() {
                     @Override
                     public void onDataChange(@NonNull DataSnapshot snapshot) {
                         String shopName=""+snapshot.child("supermarketName").getValue();
                         String shopImage=""+snapshot.child("supermarketImage").getValue();
                         String shopId=""+snapshot.child("sid").getValue();

                         shopNameTv.setText(shopName);
                         shopIdTv.setText(shopId);
                         try {
                             Picasso.get().load(shopImage).placeholder(R.drawable.ic_store).into(profileIv);
                         }
                         catch (Exception e)
                         {
                             profileIv.setImageResource(R.drawable.ic_store);
                         }


                     }

                     @Override
                     public void onCancelled(@NonNull DatabaseError error) {

                     }
                 });
     }
 */
    private void inputData(View v) {
        String ratings = "" + ratingBar.getRating();
        String review = reviewEt.getText().toString().trim();

        String timestamp = "" + System.currentTimeMillis();

        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("uid", "" + firebaseAuth.getUid());
        hashMap.put("ratings", "" + ratings);
        hashMap.put("review", "" + review);
        hashMap.put("timestamp", "" + timestamp);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Supermarkets").child(shopId).child("Ratings");
        ref
                .push()
                .setValue(hashMap).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(v.getContext(), "Review published Successfuly" +
                        "", Toast.LENGTH_SHORT).show();
            }
        });
    }
}