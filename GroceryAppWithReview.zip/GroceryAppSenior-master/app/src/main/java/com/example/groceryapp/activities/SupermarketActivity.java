package com.example.groceryapp.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.groceryapp.R;
import com.example.groceryapp.adapters.AdapterReview;
import com.example.groceryapp.models.ModelReview;
import com.example.groceryapp.models.ModelSupermarket;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SupermarketActivity extends AppCompatActivity {
    private ImageButton rateIv,shreviewIv;
    private String ShopName,shopId;
    private RatingBar ratingBar4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supermarket);

        ModelSupermarket sm = (ModelSupermarket) getIntent().getSerializableExtra("supermarket");

        TextView title = findViewById(R.id.supermarketNameTv);
        TextView address = findViewById(R.id.supermarketAddressTv);
        ImageView supermarketIcon = findViewById(R.id.supermarketIconIv);
        String icon = sm.getSupermarketImage();
        rateIv=findViewById(R.id.rateIv);
        shreviewIv=findViewById(R.id.shreviewIv);
        //ratingBar4=findViewById(R.id.ratingBar4);

        title.setText(sm.getSupermarketName());
        address.setText(sm.getAddress());

        Intent intent=getIntent();
        ShopName=intent.getStringExtra("ShopName");
        shopId=intent.getStringExtra("shopId");

        rateIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(SupermarketActivity.this, writwReviewActivity.class);
                intent1.putExtra("supermarket",sm);
                startActivity(intent1);
            }
        });

        Picasso.get().load(sm.getSupermarketImage()).into(supermarketIcon);

        shreviewIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SupermarketActivity.this, ShopReviewActivity.class);
                intent.putExtra("supermarket",sm);
                startActivity(intent);

            }
        });

        LoadReviews();

    }
    private float ratinngSum=0;
    private void LoadReviews() {
        FirebaseDatabase.getInstance().getReference().child("Supermarkets")
                .child(shopId).child("Ratings").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ratinngSum=0;
                for (DataSnapshot ds : snapshot.getChildren()) {
                    float rating=Float.parseFloat(""+ds.child("ratings").getValue());
                    ratinngSum=ratinngSum+rating;
                }

                long numberOfReviews= snapshot.getChildrenCount();
                float avgRating=ratinngSum/numberOfReviews;
                ratingBar4.setRating(avgRating);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }


}